# KRrfid-master
Library Arduino untuk mempermudah membaca TAG RFID RC522.
